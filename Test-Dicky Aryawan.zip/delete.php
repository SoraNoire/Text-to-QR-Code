<?php

include_once("config.php");
 
$id_barang = $_GET['id_barang'];
 
$result = mysqli_query($mysqli, "DELETE FROM barang WHERE id_barang='$id_barang'");

header("Location:index.php");
?>