<?php

include_once("config.php");
include "phpqrcode/qrlib.php";

$result = mysqli_query($mysqli, "SELECT * FROM barang ORDER BY nama_barang DESC");
  

$tempdir = "qrcode-img/";       

if (!file_exists($tempdir))   
mkdir($tempdir);

$no=1;
?>
 
<html>
<head>    
    <title>Homepage</title>
</head>
 
<body>
<a href="add.php">Tambah Barang</a><br/><br/>

<a href="angka.php">OPTIONAL CHALLENGE BUT MATTER</a><br/><br/>
 
    <table width='80%' border=1>
 
    <tr>
    <th>No</th> <th>Nama Barang</th> <th>Id barang</th> <th>Tanggal Beli</th> <th>Kota</th> <th>QR</th> <th>Update</th>
    </tr>
    <?php  
    while($user_data = mysqli_fetch_array($result)) {  
        $text = 


//Switch area jakarta pembelian bulan Juni tahun 2021 ke 5
        $teks_qrcode=$user_data['nama_barang']." area ".$user_data['kota']." pembelian bulan ".date('F',strtotime($user_data['tgl_pembelian']))." tahun ".date('Y',strtotime($user_data['tgl_pembelian']))." ke ".$user_data['queri'];
        $namafile=$user_data['id_barang'].".png";
        $quality="H";
        $ukuran=5; 
        $padding=1;   
        QRCode::png($teks_qrcode, $tempdir.$namafile, $quality, $ukuran, $padding);   
        
        
        echo "<tr>";
        echo "<td>".$no++."</td>";
        echo "<td>".$user_data['nama_barang']."</td>";
        echo "<td>".$user_data['id_barang']."</td>";
        echo "<td>".$user_data['tgl_pembelian']."</td>";    
        echo "<td>".$user_data['kota']."</td>";    
        echo "<td>"."<img src='qrcode-img/".$user_data['id_barang'].".png'"." width='100' height='100' />"."</td>";    
        echo "<td><a href='edit.php?id_barang=$user_data[id_barang]'>Edit</a> | <a href='delete.php?id_barang=$user_data[id_barang]'>Delete</a></td></tr>";        
    }
    ?>
    </table>
</body>
</html>