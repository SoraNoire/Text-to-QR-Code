<html>
<head>
    <title>Tambah Barang</title>
</head>
 
<body>
    <a href="index.php">Go to Home</a>
    <br/><br/>
 
    <form action="add.php" method="post" name="form1">
        <table width="25%" border="0">
            <tr> 
                <td>Nama Barang</td>
                <td><input type="text" name="nama_barang"></td>
            </tr>
            <tr> 
                <td>Kode Barang</td>
                <td><input type="text" name="kode_barang"></td>
            </tr>
            <tr> 
                <td>Tgl Pembelian</td>
                <td><input type="date" name="tgl_pembelian"></td>
            </tr>
            <tr> 
                <td>Kota</td>
                <td><input type="text" name="kota"></td>
            </tr>
            <tr> 
                <td>Kode kota</td>
                <td><input type="text" name="kode_kota"></td>
            </tr>
            <tr> 
                <td>Pembelian Ke</td>
                <td><input type="text" name="queri"></td>
            </tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Add"></td>
            </tr>
        </table>
    </form>
    
    <?php
 

    if(isset($_POST['Submit'])) {
        $id_barang = $_POST['kode_barang'].$_POST['kode_kota'].date('my',strtotime($_POST['tgl_pembelian'])).$_POST['queri'];
        $nama_barang = $_POST['nama_barang'];
        $kode_barang = $_POST['kode_barang'];
        $tgl_pembelian = $_POST['tgl_pembelian'];
        $kota = $_POST['kota'];
        $kode_kota = $_POST['kode_kota'];
        $queri = $_POST['queri'];
        
    
        include_once("config.php");
                
   
        $result = mysqli_query($mysqli, "INSERT INTO barang(id_barang,nama_barang,kode_barang,tgl_pembelian,kota,kode_kota,queri) 
        VALUES('$id_barang','$nama_barang','$kode_barang','$tgl_pembelian','$kota','$kode_kota','$queri')");
        

        echo "Barang Berhasil Dutambahkan. <a href='index.php'>Lihat Disini</a>";
    }
    ?>
</body>
</html>