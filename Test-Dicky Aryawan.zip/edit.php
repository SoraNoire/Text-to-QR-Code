<?php

include_once("config.php");
 
if(isset($_POST['update']))
{    
    $id_barang = $_POST['id_barang'];
    
    $nama_barang=$_POST['nama_barang'];
    $kode_barang=$_POST['kode_barang'];
    $tgl_pembelian=$_POST['tgl_pembelian'];
    $kota=$_POST['kota'];
    $kode_kota=$_POST['kode_kota'];
    $queri=$_POST['queri'];
    
    $result = mysqli_query($mysqli, "UPDATE barang SET nama_barang='$nama_barang', kode_barang='$kode_barang', tgl_pembelian='$tgl_pembelian', kota='$kota', kode_kota='$kode_kota', queri='$queri' WHERE id_barang='$id_barang'");
    
    header("Location: index.php");
}
?>
<?php
$id_barang = $_GET['id_barang'];
$result = mysqli_query($mysqli, "SELECT * FROM barang WHERE id_barang='$id_barang'");
 
while($user_data = mysqli_fetch_array($result))
{
    $nama_barang=$user_data['nama_barang'];
    $kode_barang=$user_data['kode_barang'];
    $tgl_pembelian=$user_data['tgl_pembelian'];
    $kota=$user_data['kota'];
    $kode_kota=$user_data['kode_kota'];
    $queri=$user_data['queri'];
}
?>
<html>
<head>    
    <title>Edit User Data</title>
</head>
 
<body>
    <a href="index.php">Home</a>
    <br/><br/>
    
    <form name="update_user" method="post" action="edit.php">
        <table border="0">
            <tr> 
                <td>Nama Barang</td>
                <td><input type="text" name="nama_barang" value=<?php echo $nama_barang;?>></td>
            </tr>
            <tr> 
                <td>Kode Barang</td>
                <td><input type="text" name="kode_barang" value=<?php echo $kode_barang;?>></td>
            </tr>
            <tr> 
                <td>Tanggal Pembelian</td>
                <td><input type="date" name="tgl_pembelian" value=<?php echo $tgl_pembelian;?>></td>
            </tr>
            <tr> 
                <td>Kota</td>
                <td><input type="text" name="kode_barang" value=<?php echo $kota;?>></td>
            </tr>
            <tr> 
                <td>Kode Kota</td>
                <td><input type="text" name="kode_barang" value=<?php echo $kode_kota;?>></td>
            </tr>
            <tr> 
                <td>Pembelian Ke</td>
                <td><input type="text" name="kode_barang" value=<?php echo $queri;?>></td>
            </tr>
            <tr>
                <td><input type="hidden" name="id_barang" value=<?php echo $_GET['id_barang'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>